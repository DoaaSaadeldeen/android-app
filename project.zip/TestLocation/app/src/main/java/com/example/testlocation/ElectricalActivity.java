package com.example.testlocation;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

public class ElectricalActivity extends AppCompatActivity {

    String txt;
    TextView scroll_txt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_electrical);

        txt=" الخطوات التى يجب اتباعها عند نشوب حريق نتيجة لماس كهربائى، و فيما يلى أهم الخطوات التى يجب اتباعها:\n" +
                "\n" +
                "1-حاول العثور على الجهاز الذى يتسبب فى نشوب حريق كهربائي، يجب فصل التيار عنه على الفور، من خلال لوحة المفاتيح الأوتوماتك التى تكون موجودة عادة بجوار الباب.\n" +
                "\n" +
                "2 -إذا كانت النار صغيرة، يمكنك إخمادها عن طريق إزالة مصدر الأكسجين باستخدام الملابس، أو من خلال بطانية ثقيلة، يتم إلقائها على مصدر النار او من خلال التراب او الرمل ، بحيث تمنع الأكسجين من الوصول لمكان اللهب، إذا كانت النار صغيرة وآمنة للقيام بذلك.\n" +
                "\n" +
                "3- الماء هو موصل طبيعى للكهرباء، وإذا رميت الماء على حريق كهربائي، ربما تصاب بالصدمة أو الصعق بالكهرباء، فان الماء لن يحد من انتشار النار بل سيساهم فى توسيع دائرة التيار، فى جميع أنحاء الغرفة وربما إشعال المواد القابلة للاشتعال.\n" +
                "\n" +
                "4-الحرائق الكهربائية هى حريق من الفئة C، مما يعنى أنك ستحتاج إلى مطفأة مناسبة لهذا النوع من الحريق. معظم طفايات الحريق السكنية متعددة الأغراض وتسمى ABC ، ولكن من الضرورى التحقق من ذلك قبل استخدامه على حريق كهربائي.\n" +
                "\n" +
                "5-إذا كنت غير قادر على إطفاء الحريق الكهربائي، يجب عليك الخروج من مكان الحريق فورا، وإخلاء المكان من العنصر البشري، واستدعاء رجال الأطفاء.\n" +
                "\n" +
                "6-أغلق الباب وأنت تغادر لاحتواء النار، ولا تحاول دخول منزلك حتى يتم احتواء الحريق من قبل رجال الإطفاء.";
         scroll_txt = findViewById(R.id.scroll_txt);
        scroll_txt.setMovementMethod(new ScrollingMovementMethod());
        scroll_txt.append(txt);

    }
}