package com.example.testlocation;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.telephony.SmsManager;
import android.text.InputType;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.List;
import java.util.Locale;


public class MainActivity extends AppCompatActivity implements LocationListener,View.OnClickListener {
    EditText edit_number;
    Button police_btn,fire_btn,ambulance_btn,elect_btn,person_btn,add_btn,cancel_btn;
    String police_num="122",ambulance_num="123",added_number="",fire_num="180", elect_num="121", person_num = "";
    String standard_msg="help me please, my location is ", number ="",address="";
    String[] permissions ={Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.INTERNET,Manifest.permission.SEND_SMS,Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_SMS};
    Double longitude=0.0,latitude=0.0;
    int request_code=0;
    SharedPreferences sharedPreferences;
    LocationManager mgr;

  @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mgr= (LocationManager) getSystemService(Context.LOCATION_SERVICE);
          if (ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                  // TODO: Consider calling
                  ActivityCompat.requestPermissions(MainActivity.this,permissions,request_code);
              }else {
                  mgr.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, MainActivity.this);
              }

        add_btn=findViewById(R.id.add_btn);
        cancel_btn=findViewById(R.id.cancel_btn);
        edit_number=findViewById(R.id.edit_number);
        police_btn = findViewById(R.id.police_btn);
        ambulance_btn = findViewById(R.id.ambulance_btn);
        fire_btn = findViewById(R.id.fire_btn);
        elect_btn=findViewById(R.id.elect_btn);
        person_btn=findViewById(R.id.person_btn);

        police_btn.setOnClickListener(this);
        ambulance_btn.setOnClickListener(this);
        fire_btn.setOnClickListener(this);
        elect_btn.setOnClickListener(this);
        person_btn.setOnClickListener(this);


}//end of onCreate

    //handeling buttons
    @Override
    public void onClick(View v) {
      if(v.getId()==R.id.police_btn || v.getId()==R.id.ambulance_btn || v.getId()==R.id.fire_btn || v.getId()==R.id.elect_btn)
        {
            if (v.getId() == R.id.police_btn) {
                number = police_num;
            } else if (v.getId() == R.id.ambulance_btn) {
                number = ambulance_num;
            } else if (v.getId() == R.id.fire_btn) {
                number = fire_num;
            } else if (v.getId() == R.id.elect_btn) {
                number = elect_num;
            }
            send_message();
        }
            else  if(v.getId()==R.id.person_btn){
                sharedPreferences=getPreferences(MODE_PRIVATE);
                added_number = (sharedPreferences.getString("phone", ""));
                if(added_number!="")//already adding is 7asl
                {
                    number=added_number;
                    send_message();
                }else{
                    Toast.makeText(MainActivity.this, "sorry..! you don't add any number to call", Toast.LENGTH_SHORT).show();
                }
            }
        }//end of onClick

    private boolean isCorrect(String person_num) {

        for(int i=0;i<person_num.length();i++)
        {
            if(person_num.charAt(i)>='0' && person_num.charAt(i)<='9') {
                continue;
            }else{
                return false;
            }
        }
        return true;
    }//end isCorrect

 @Override
    public void onLocationChanged(@NonNull final Location location) {

     new Handler().postDelayed(new Runnable() {
         public void run(){
             longitude = location.getLongitude();
             latitude = location.getLatitude();
             Toast.makeText(MainActivity.this, ""+latitude+ "\n" +longitude, Toast.LENGTH_SHORT).show();
             geoCoder_Method();
             mgr.removeUpdates(MainActivity.this);
         }
     }, 7000);
 }//end of onLocationChange

    public void geoCoder_Method()
    {
        Geocoder geocoder = new Geocoder(MainActivity.this, Locale.getDefault());
        List<Address> addresses ;//......here is exception
        try {
            addresses = geocoder.getFromLocation(latitude, longitude, 1);
            address=addresses.get(0).getAddressLine(0); // If any additional address line present than only, check with max available address lines by getMaxAddressLineIndex();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }//end geoCoderMethod()
    public void send_message()
    {
        if(address!="") {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(number, null, standard_msg + " " + address, null, null);
            Toast.makeText(MainActivity.this, "Message has been sent successfully " + address, Toast.LENGTH_SHORT).show();
        }else{
            if (ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling
                ActivityCompat.requestPermissions(MainActivity.this,permissions,request_code);
            }else {
                mgr.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, MainActivity.this);
            }
        }
    }//end of send message

    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,@NonNull int[] grantResults){
        if(requestCode==request_code)
        {
            if (ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                    && ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(MainActivity.this,permissions,request_code);
            }
            else {
                mgr.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, MainActivity.this);
            }
        }
    }//end of onRequestPermission
    //........................................................start option menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater =getMenuInflater();
        inflater.inflate(R.menu.menu_file,menu);
        return true;
    }//end onCreateOptionsMenu

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
      switch (item.getItemId())
      {
           case R.id.add:  show_dialog_number();
              Toast.makeText(getApplicationContext(),"you pressed add" ,Toast.LENGTH_LONG).show();
              break;
            case R.id.advices_for_electrical_item :
                Intent intent=new Intent(MainActivity.this,ElectricalActivity.class);
                startActivity(intent);
              break;
            case R.id.primary_ambulance_item :
                Intent intent2=new Intent(MainActivity.this,AmbulanceAct.class);
                startActivity(intent2);
             break;
      }
      return true;
    }
    ////////.............................................end option menu
    //add number>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

    private void show_dialog_number() {

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Adding Number");
        // Set up the input
         final EditText input = new EditText(this);
// Specify the type of input expected; this, for example, sets the input as a password, and will mask the text
        input.setInputType( InputType.TYPE_CLASS_TEXT);
        builder.setView(input);

// Set up the buttons
        builder.setPositiveButton("add", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                person_num=input.getText().toString();
                if(person_num.length()==11 && isCorrect(person_num)) {
                    sharedPreferences = getPreferences(MODE_PRIVATE);
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putString("phone", person_num);
                    editor.commit();
                    Toast.makeText(MainActivity.this, "number added successfully", Toast.LENGTH_SHORT).show();
                }else {
                    person_num="";
                    Toast.makeText(MainActivity.this, "number not add because of wrong input", Toast.LENGTH_SHORT).show();
                }
                dialog.cancel();
            }//end of on click
        });/// add button

        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(MainActivity.this, "operation is canceled successfully", Toast.LENGTH_SHORT).show();
                dialog.cancel();
            }
        });//cancel button

        builder.show();
    }//show dialog number


}